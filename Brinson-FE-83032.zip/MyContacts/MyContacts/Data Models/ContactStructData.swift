//
//  ContactStructData.swift
//  MyContacts
//
//  Created by Gregory Cason Brinson on 12/7/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI
import CoreData

// Array of MusicAlbum structs for use only in this file
fileprivate var contactStructList = [ContactStruct]()

/*
 ***********************************
 MARK: - Create ContactStruct Database
 ***********************************
 */

public func createContactStructDatabase() {

    contactStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: "ContactsData.json", fileLocation: "Main Bundle")

    populateDatabase()
}

/*
*********************************************
MARK: - Populate Database If Not Already Done
*********************************************
*/
func populateDatabase() {

    // ❎ Get object reference of CoreData managedObjectContext from the persistent container
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    //----------------------------
    // ❎ Define the Fetch Request
    //----------------------------
    let fetchRequest = NSFetchRequest<Contact>(entityName: "Contact")

    fetchRequest.sortDescriptors = [
        // Primary sort key: artistName
        NSSortDescriptor(key: "lastName", ascending: true),
        NSSortDescriptor(key: "firstName", ascending: true)
    ]
    
    var listOfAllContactEntitiesInDatabase = [Contact]()

    do {
        listOfAllContactEntitiesInDatabase = try managedObjectContext.fetch(fetchRequest)
    } catch {
        print("Populate Database Failed!")
        return
    }

    if listOfAllContactEntitiesInDatabase.count > 0 {
        // Database has already been populated
        print("Database has already been populated!")
        return
    }

    print("Database will be populated!")

    for contactStruct in contactStructList {

        // ❎ Create an instance of the Song entity in CoreData managedObjectContext
        let contactEntity = Contact(context: managedObjectContext)

        // ❎ Dress it up by specifying its attributes
        contactEntity.firstName = contactStruct.firstName
        contactEntity.lastName = contactStruct.lastName
        contactEntity.company = contactStruct.company
        contactEntity.phone = contactStruct.phone
        contactEntity.email = contactStruct.email
        contactEntity.url = contactStruct.url
        contactEntity.notes = contactStruct.notes
        contactEntity.addressLine1 = contactStruct.addressLine1
        contactEntity.addressLine2 = contactStruct.addressLine2
        contactEntity.addressCity = contactStruct.addressCity
        contactEntity.addressState = contactStruct.addressState
        contactEntity.addressZipcode = contactStruct.addressZipcode
        contactEntity.addressCountry = contactStruct.addressCountry
        
        /*
         ======================================================
         Create an instance of the Photo Entity and dress it up
         ======================================================
         */
        // ❎ Create an instance of the Photo Entity in CoreData managedObjectContext
        let photoEntity = Photo(context: managedObjectContext)

        // Obtain the photo image from Assets.xcassets as UIImage
        let photoUIImage = UIImage(named: contactStruct.photoFullFilename)

        // Convert photoUIImage to data of type Data (Binary Data) in JPEG format with 100% quality
        let photoData = photoUIImage?.jpegData(compressionQuality: 1.0)

        // Assign photoData to Core Data entity attribute of type Data (Binary Data)
        photoEntity.contactPhoto = photoData!

        /*
         ==============================
         Establish Entity Relationships
         ==============================
        */
        contactEntity.photo = photoEntity
        photoEntity.contact = contactEntity

        /*
         ==================================
         Save Changes to Core Data Database
         ==================================
        */
        // ❎ CoreData Save operation
        do {
            try managedObjectContext.save()
        } catch {
            return
        }
    }   // End of for loop
}

