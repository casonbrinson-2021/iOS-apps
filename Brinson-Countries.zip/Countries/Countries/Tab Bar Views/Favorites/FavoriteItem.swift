
//

//  FavoriteItem.swift

//  Countries

//

//  Created by Cason Brinson on 9/17/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.

//

 

import SwiftUI

 

struct FavoriteItem: View {

   

    // Input Parameter

    let country: Country

   

    var body: some View {

        HStack {

            // Public function getImageFromUrl is given in UtilityFunctions.swift

            getImageFromUrl(url: country.flagImageUrl, defaultFilename: "ImageUnavailable")

                .resizable()

                .aspectRatio(contentMode: .fit)

                .frame(width: 100.0)

           

            VStack(alignment: .leading) {

                Text(country.name)

                HStack {

                    Text("Population: ")

                    countryPopulation

                }

                HStack {

                    Text("Capital: ")

                    Text(country.capital)

                }

            }

            // Set font and size for the whole VStack content

            .font(.system(size: 14))

           

        }   // End of HStack

    }

   

    var countryPopulation: Text {

        let populationInt = country.population

       

        // Add thousand separators to populationInt

        let numberFormatter = NumberFormatter()

        numberFormatter.usesGroupingSeparator = true

        numberFormatter.groupingSize = 3

       

        let populationString = numberFormatter.string(from: populationInt as NSNumber)

        return Text(populationString!)

    }

}

 

struct FavoriteItem_Previews: PreviewProvider {

    static var previews: some View {

        FavoriteItem(country: countryStructList[0])

    }

}

 
