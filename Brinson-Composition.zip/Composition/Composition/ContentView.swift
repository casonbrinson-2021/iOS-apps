//
//  ContentView.swift
//  Composition
//
//  Created by Cason Brinson on 8/27/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.

//This is the view that will be shown to the user when the app launches

import SwiftUI

struct ContentView: View {
    
    //constant declarations
    let numberOfPhotos = 12
    let listOfPhotoCaptions = ["War Memorial Chapel Pylons","Alumni Mall","Lane Stadium","Drill Field","Duck Pond","Chapel Pylons","Burruss Hall","Lvery Hall","Moss Art Center","A View of the Main Campus","Goodwin Hall","Squires Student Center"]
    
    //since we gave it an initial value it is not a parameter
    @State private var photoNumber = 1  //if state var is changed then the content view is refreshed
    
    
    var body: some View {
        ZStack {
            //color the backgrond of the entire screen light gray
            Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
            
            VStack {
                HStack {
                    
                    //profile photo view is constructed as a structure in the ProfilePhoto.swift file
                    ProfilePhoto(filename: "OsmanBalci")
                    
                    VStack(alignment: .leading) {
                        Text("Osman Balci")
                            .font(.title)
                            .foregroundColor(.primary)
                        Text("Professor of Computer Science")
                            .font(.headline)
                            .foregroundColor(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                            .multilineTextAlignment(/*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/)
                        
                        //Email view is constructed below as a constructor
                        Email(address: "balci@vt.edu")
                    } //End of VStack
                } //End of HStack
                
                CurrentDateAndTime()
                
                //photo image is returned from a funciton
                photoImage(number: self.photoNumber)
                
                //photo caption view is constructed as a variable value
                photoCaption
                    .padding(.bottom, 10)
                
                Button(action: {
                    self.photoNumber = Int.random(in: 1...self.numberOfPhotos)
                }) {
                    HStack {
                        //arrowtriangle.up.square icon in Apple SF Symbols
                        Image(systemName: "arrowtriangle.up.square")
                            .imageScale(.large)
                            .font(Font.title.weight(.regular))
                            .foregroundColor(.red)
                        Text("Show Photo Randomly")
                            .foregroundColor(.purple)
                }
                
            }
        }
    }
}
    
    //view constructed as a variable within the same structure
    var photoCaption: Text {
        let caption = "Photo \(self.photoNumber): \(listOfPhotoCaptions[self.photoNumber - 1])"
        return Text(caption)
    }
    
}

//view returned from a function
func photoImage(number: Int) -> some View {
    return AnyView(
        Image("photo\(String(number))")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(minWidth: 300, maxWidth: 500, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            .padding()
    )
}

struct Email: View {
    let address: String
    
    var body: some View {
        HStack {
            Image(systemName: "envelope")
                .imageScale(.small)
                .font(Font.title.weight(.light))
                .foregroundColor(.blue)
            Text(address)
                .fixedSize(horizontal: false, vertical: true)
                .multilineTextAlignment(.leading)
        }
        
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
