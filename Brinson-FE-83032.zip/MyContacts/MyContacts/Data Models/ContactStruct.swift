//
//  ContactStruct.swift
//  MyContacts
//
//  Created by Gregory Cason Brinson on 12/7/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct ContactStruct: Decodable {
    
    var firstName: String
    var lastName: String
    var photoFullFilename: String
    var company: String
    var phone: String
    var email: String
    var url: String
    var notes: String
    var addressLine1: String
    var addressLine2: String
    var addressCity: String
    var addressState: String
    var addressZipcode: String
    var addressCountry: String
    
}
