//
//  ContentView.swift
//  Calculator
//
//  Created by Cason Brinson on 9/2/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.
//

import SwiftUI

//fileprivate makes the variable accessible anywhere inside this file only
fileprivate var errorOccurred = false
fileprivate var leftSideValue = 0.0
fileprivate var rightSideValue = 0.0

struct ContentView: View {
    
    //adding state variables here
    @State private var selectBGColor = Color.gray.opacity(0.1)
    @State private var result = ""
    
    var body: some View {
        
        ZStack {
            //color the background with the state var selectBGColor
            selectBGColor
                .edgesIgnoringSafeArea(.all)
            
            //place the background color picker in the top right corner
            VStack {
                HStack {
                    Spacer()
                    ColorPicker("", selection: $selectBGColor)
                        .padding()
                }
                Spacer()
            }
            
            VStack(spacing: 40) {
                //display results view
                Text(result)
                    .font(.headline)
                    .padding()
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(/*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/)
                    .background(
                        RoundedRectangle(cornerRadius: 16)
                            .strokeBorder(Color.red, lineWidth: 2)
                            .frame(minWidth: 300, maxWidth: UIScreen.main.bounds.width - 60, minHeight: 40, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    )
                
                //drag gesture that removes the last character on the display
                    
                    .gesture(
                        DragGesture()
                            .onEnded { value in
                                self.handleDragGesture()    //will define later
                            }
                    )
                
                HStack(spacing: 130) {
                    Button(action: {
                        self.buttonTapped(buttonTag: 10)
                    }) {
                        Text("Clear")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag: 11)
                    }) {
                        Image(systemName: "divide")
                            .foregroundColor(.black)
                    }
                } //end of HStack
                
                //Row 2
                HStack(spacing: 30) {
                    Button(action: {
                        self.buttonTapped(buttonTag: 7)
                    }) {
                        Image(systemName: "7.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag: 8)
                    }) {
                        Image(systemName: "8.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag: 9)
                    }) {
                        Image(systemName: "9.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag: 12)
                    }) {
                        Image(systemName: "multiply")
                            .foregroundColor(.black)
                    }
                } //end of HStack
                
                //Row 3
                HStack(spacing: 30) {
                    Button(action: {
                        self.buttonTapped(buttonTag: 4)
                    }) {
                        Image(systemName: "4.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag: 5)
                    }) {
                        Image(systemName: "5.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag: 6)
                    }) {
                        Image(systemName: "6.circle")
                    }
                    Button(action: {
                        self.buttonTapped(buttonTag: 13)
                    }) {
                        Image(systemName: "minus")
                            .foregroundColor(.black)
                    }
                } //end of HStack
                    
                    //Row 4
                    HStack(spacing: 30) {
                        Button(action: {
                            self.buttonTapped(buttonTag: 1)
                        }) {
                            Image(systemName: "1.circle")
                        }
                        Button(action: {
                            self.buttonTapped(buttonTag: 2)
                        }) {
                            Image(systemName: "2.circle")
                        }
                        Button(action: {
                            self.buttonTapped(buttonTag: 3)
                        }) {
                            Image(systemName: "3.circle")
                        }
                        Button(action: {
                            self.buttonTapped(buttonTag: 14)
                        }) {
                            Image(systemName: "plus")
                                .foregroundColor(.black)
                        }
                    } //end of HStack
                    
                    //Row 5
                    HStack {
                        Button(action: {
                            self.buttonTapped(buttonTag: 0)
                        }) {
                            Image(systemName: "0.circle")
                        }.padding(.trailing, 90)
                        Button(action: {
                            self.buttonTapped(buttonTag: 15)
                        }) {
                            Image(systemName: "dot.circle")
                        }.padding(.trailing, 22)
                        Button(action: {
                            self.buttonTapped(buttonTag: 16)
                        }) {
                            Image(systemName: "equal")
                                .foregroundColor(.black)
                        }
                    } //end of HStack
                    
            } //end of VStack
                .imageScale(.large)
                .font(Font.title.weight(.regular))
                .padding()
                
        } //end of ZStack
    } //end of body
        
    //func to handle drag gesture
    func handleDragGesture() {
        //delete the last character upon drag gesture
        result = String(result.dropLast())
    }
    
    
    //func to handle buttonTapped
    func buttonTapped(buttonTag: Int) {
            
        switch buttonTag {
        
        case 0...9: //a number from 0 to 9 is tapped
            result += String(buttonTag)
        
        case 10:    //clear button tapped
            errorOccurred = false
            leftSideValue = 0.0
            rightSideValue = 0.0
            result = ""
            
        case 11: //divide button tapped
            if result.isEmpty {return}
            result += " ÷ "
            
        case 12: //multiply button is tapped
            if result.isEmpty {return}
            result += " x "
            
        case 13: //subtract button is tapped
            if result.isEmpty {return}
            result += " - "
            
        case 14: //add button is tapped
            if result.isEmpty {return}
            result += " + "
        
        case 15: //period button is tapped
            if result.isEmpty{return}
            result += "."
            
        case 16: //equal button is tapped
            if result.isEmpty{return}
            result += " = "
            
            for char in result {
                if char == "÷" {
                    computeResult(forOperator: "÷")
                } else if char == "x" {
                    computeResult(forOperator: "x")
                } else if char == "-" {
                    computeResult(forOperator: "-")
                } else if char == "+" {
                    computeResult(forOperator: "+")
                }
            }
            
        default:
            print("Button tag number is out of range!")
        }
    }
        
    
    //func to compute result
    func computeResult(forOperator: String) {
        if errorOccurred {return}
        
        var computedResult = 0.0
        
        let resultWithoutEqualSign = result.replacingOccurrences(of: "=", with: "")
        let parts = resultWithoutEqualSign.components(separatedBy: forOperator)
        
        //prevent multiple operators
        if parts.count  > 2 {
            result += "Error"
            errorOccurred = true
            return
        }
        
        //remove spaces at the beginning and end
        let part0 = parts[0].trimmingCharacters(in: .whitespacesAndNewlines)
        let part1 = parts[1].trimmingCharacters(in: .whitespacesAndNewlines)
        
        //converting the string values to doubles
        let part0Entered: Double? = Double(part0)
        let part1Entered: Double? = Double(part1)
        
        //this part never works for some reason (need to ask about this because
        //it is exactly the same as his code online)
        if let part0Value = part0Entered {
            //conversion of string part0 to double is succesful
            leftSideValue = part0Value
        
            if let part1Value = part1Entered {
                //conversion of string part1 to double is succesful
                rightSideValue = part1Value
            } else {
                result += "Error"
                errorOccurred = true
                return
            }
        } else {
            result += "Error"
            errorOccurred = true
            return
        }
        
        
        switch forOperator {
        case "÷":
            computedResult = leftSideValue / rightSideValue
        case "x":
            computedResult = leftSideValue * rightSideValue
        case "-":
            computedResult = leftSideValue - rightSideValue
        case "+":
            computedResult = leftSideValue + rightSideValue
        default:
            print("Invalid arithmetic operator symbol!")
        }
        
        //add thousand separators to computed result
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal
        numberFormatter.usesGroupingSeparator = true
        numberFormatter.groupingSize = 3
        
        let resultWithSeperators = numberFormatter.string(for: computedResult)
        
        //append resultWithSeperators to 'result' to display it
        result += resultWithSeperators!
        
    }
        
        
        
        
} //end of ContentView

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
