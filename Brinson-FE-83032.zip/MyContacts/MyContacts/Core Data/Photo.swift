//
//  Photo.swift
//  MyContacts
//
//  Created by Gregory Cason Brinson on 12/7/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//


import Foundation
import CoreData

public class Photo: NSManagedObject, Identifiable {

    @NSManaged public var contactPhoto: Data?
    @NSManaged public var contact: Contact?

}

 

