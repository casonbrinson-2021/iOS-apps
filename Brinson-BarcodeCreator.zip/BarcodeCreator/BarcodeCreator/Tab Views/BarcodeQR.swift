//
//  BarcodeQR.swift
//  BarcodeCreator
//
//  Created by Cason Brinson on 9/26/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.
//
 
import SwiftUI

 

struct BarcodeQR: View {

   

    @State private var textFieldValue = ""

    @State private var valueEntered = ""

   

    var body: some View {

        NavigationView {

            Form {

                Section {

                    Text("QR (Quick Response) barcode allows to encode over 4000 characters. In practice, QR codes often contain data for a locator, identifier, or tracker that points to a website or application.")

                        .font(.custom("Helvetica", size: 14))

                }

                Section {

                    HStack {

                        TextField("Enter input to generate barcode", text: $textFieldValue,

                            onCommit: {

                                // Record entered value after Return key is pressed

                                self.valueEntered = self.textFieldValue

                            })

                            .font(.subheadline)

                            .textFieldStyle(RoundedBorderTextFieldStyle())

                            .keyboardType(.default)

                            .autocapitalization(.none)

                            .disableAutocorrection(true)

                       

                        // Button to clear the text field

                        Button(action: {

                            self.textFieldValue = ""

                            self.valueEntered = ""

                        }) {

                            Image(systemName: "clear")

                                .imageScale(.medium)

                                .font(Font.title.weight(.regular))

                        }

                    }   // End of HStack

                        .padding(.horizontal)

                        .frame(minWidth: 300, maxWidth: 500, alignment: .center)

                   

                }   // End of HStack

               

                if !valueEntered.isEmpty {

                    Section {

                        NavigationLink(destination: barcodeGeneration) {

                            HStack {

                                Image(systemName: "gear")

                                    .imageScale(.medium)

                                    .font(Font.title.weight(.regular))

                                    .foregroundColor(.blue)

                                Text("Generate QR Barcode")

                                    .font(.system(size: 16))

                            }

                        }

                        .frame(minWidth: 300, maxWidth: 500, alignment: .center)

                    }

                }

            }   // End of Form

                .navigationBarTitle(Text("Generate QR Barcode"), displayMode: .inline)

           

        }   // End of NavigationView

        // Use single column navigation view for iPhone and iPad

        .navigationViewStyle(StackNavigationViewStyle())

       

    }   // End of body

   

    var barcodeGeneration: some View {

        let barcodeImage: UIImage = createBarcode(from: valueEntered, type: "CIQRCodeGenerator", scaleFactor: 8)!

        return AnyView(

            BarcodeCreated(input: valueEntered, image: barcodeImage)

                .navigationBarTitle(Text("Generated QR Barcode"), displayMode: .inline)

        )

    }

}

 

struct BarcodeQR_Previews: PreviewProvider {

    static var previews: some View {

        BarcodeQR()

    }

}

 
