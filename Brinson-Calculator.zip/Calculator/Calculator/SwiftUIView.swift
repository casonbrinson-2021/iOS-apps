//
//  SwiftUIView.swift
//  Calculator
//
//  Created by CS3714 on 9/2/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIView()
    }
}
