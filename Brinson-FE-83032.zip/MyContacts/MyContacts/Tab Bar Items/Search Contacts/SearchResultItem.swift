//
//  SearchResultItem.swift
//  MyContacts
//
//  Created by Gregory Cason Brinson on 12/8/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct SearchResultItem: View {
    
    let contact: Contact
    
    var body: some View {
        HStack {
            // This public function is given in UtilityFunctions.swift
            getImageFromBinaryData(binaryData: contact.photo!.contactPhoto!, defaultFilename: "DefaultContactPhoto")
                .resizable()
                .frame(width: 80.0, height: 80.0)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white, lineWidth: 1))
                .shadow(radius: 5)

            VStack(alignment: .leading) {
                Text("\(contact.firstName ?? "") \(contact.lastName ?? "")")
                HStack {
                    Image(systemName: "phone.circle")
                        .imageScale(.small)
                        .font(Font.title.weight(.thin))
                    Text(contact.phone ?? "")
                }
                HStack {
                    Image(systemName: "envelope")
                        .imageScale(.small)
                        .font(Font.title.weight(.thin))
                    Text(contact.email ?? "")
                }
            }
            .font(.system(size: 14))
        }
    }
}

struct SearchResultItem_Previews: PreviewProvider {
    static var previews: some View {
        //SearchResultItem()
        Text("Hello world")
    }
}
