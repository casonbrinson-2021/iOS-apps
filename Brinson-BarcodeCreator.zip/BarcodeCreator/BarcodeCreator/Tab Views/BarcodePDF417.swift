//
//  BarcodePDF417.swift
//  BarcodeCreator
//
//  Created by Cason Brinson on 9/26/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.
//
 
import SwiftUI

struct BarcodePDF417: View {

   

    @State private var textFieldValue = ""

    @State private var valueEntered = ""

   

    var body: some View {

        NavigationView {

            Form {

                Section {

                    Text("PDF417 is a stacked linear barcode format used predominantly in transport, ID cards, and inventory management. PDF stands for Portable Data File. 417 indicates that each pattern in the code consists of 4 bars and spaces in a pattern that is 17 units long.")

                        .font(.custom("Helvetica", size: 14))

                }

                Section {

                    HStack {

                        TextField("Enter input to generate barcode", text: $textFieldValue,

                            onCommit: {

                                // Record entered value after Return key is pressed

                                self.valueEntered = self.textFieldValue

                            })

                            .font(.subheadline)

                            .textFieldStyle(RoundedBorderTextFieldStyle())

                            .keyboardType(.default)

                            .autocapitalization(.none)

                            .disableAutocorrection(true)

                       

                        // Button to clear the text field

                        Button(action: {

                            self.textFieldValue = ""

                            self.valueEntered = ""

                        }) {

                            Image(systemName: "clear")

                                .imageScale(.medium)

                                .font(Font.title.weight(.regular))

                        }

                    }   // End of HStack

                        .padding(.horizontal)

                        .frame(minWidth: 300, maxWidth: 500, alignment: .center)

                   

                }   // End of Section

                

                if !valueEntered.isEmpty {

                    Section {

                        NavigationLink(destination: barcodeGeneration) {

                            HStack {

                                Image(systemName: "gear")

                                    .imageScale(.medium)

                                    .font(Font.title.weight(.regular))

                                    .foregroundColor(.blue)

                                Text("Generate PDF417 Barcode")

                                    .font(.system(size: 16))

                            }

                        }

                        .frame(minWidth: 300, maxWidth: 500, alignment: .center)

                    }

                }

            }   // End of Form

                .navigationBarTitle(Text("Generate PDF417 Barcode"), displayMode: .inline)

           

        }   // End of NavigationView

        // Use single column navigation view for iPhone and iPad

        .navigationViewStyle(StackNavigationViewStyle())

       

    }   // End of body

   

    var barcodeGeneration: some View {

        let barcodeImage: UIImage = createBarcode(from: valueEntered, type: "CIPDF417BarcodeGenerator", scaleFactor: 3)!

        return AnyView(

            BarcodeCreated(input: valueEntered, image: barcodeImage)

                .navigationBarTitle(Text("Generated PDF417 Barcode"), displayMode: .inline)

        )

    }

}

 

struct BarcodePDF417_Previews: PreviewProvider {

    static var previews: some View {

        BarcodePDF417()

    }

}

 
