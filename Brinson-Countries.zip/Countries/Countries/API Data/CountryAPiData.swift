
//

//  CountryApiData.swift

//  Countries

//
//  Created by Cason Brinson on 9/17/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.

//

 

import Foundation

import SwiftUI

 

// Declare countryFound as a global mutable variable accessible in all Swift files

var countryFound = Country(id: UUID(), name: "", alpha2code: "", flagImageUrl: "", capital: "", population: 0, area: 0, languages: "", currency: "", latitude: 0.0, longitude: 0.0, delta: 0.0, deltaUnit: "degrees")

 

fileprivate var previousCategory = "", previousQuery = ""

 

/*

====================================

MARK: - Obtain Country Data from API

====================================

*/

public func obtainCountryDataFromApi(category: String, query: String) {

   

    // Avoid executing this function if already done for the same category and query

    if category == previousCategory && query == previousQuery {

        return

    } else {

        previousCategory = category

        previousQuery = query

    }

   

    // Initialization

    countryFound = Country(id: UUID(), name: "", alpha2code: "", flagImageUrl: "", capital: "", population: 0, area: 0, languages: "", currency: "", latitude: 0.0, longitude: 0.0, delta: 0.0, deltaUnit: "degrees")

 

    /*

     *************************

     *   API Documentation   *

     *************************

 

     This API does not require an API key.

    

     Search by Full Country Name

     https://restcountries.eu/rest/v2/name/germany?fullText=true

        --> Returns a JSON Array [{jsonObject}]

    

     Search by 2-letter or 3-letter country code:

     https://restcountries.eu/rest/v2/alpha/de

     https://restcountries.eu/rest/v2/alpha/deu

        --> Returns a JSON Object {jsonObject}

    

     Search by Capital City Name:

     https://restcountries.eu/rest/v2/capital/berlin

        --> Returns a JSON Array [{jsonObject}]

    

     Search by Full Country Name or Capital City Name returns the following JSON response.

     Search by 2 or 3-letter code returns the same response below without the square brackets at the top level.

     The green checkmark icon shows the JSON object attribute-value pairs we will use.

     [

         {

         ✅"name":"Germany",

         "topLevelDomain":[".de"],

         ✅"alpha2Code":"DE",

         "alpha3Code":"DEU",

         "callingCodes":["49"],

         ✅"capital":"Berlin",

         "altSpellings":["DE","Federal Republic of Germany","Bundesrepublik Deutschland"],

         "region":"Europe","subregion":"Western Europe",

         ✅"population":83783942,

         ✅"latlng":[51.0,9.0],

         "demonym":"German",

         ✅"area":357114.0,

         "gini":28.3,

         "timezones":["UTC+01:00"],

         "borders":["AUT","BEL","CZE","DNK","FRA","LUX","NLD","POL","CHE"],

         "nativeName":"Deutschland",

         "numericCode":"276",

         ✅"currencies":[{"code":"EUR","name":"Euro","symbol":"€"}],

         ✅"languages":[{"iso639_1":"de","iso639_2":"deu","name":"German","nativeName":"Deutsch"}],

         "translations":{...},

     *****

     Unfortunately we cannot use this URL for the flag image since SVG is not natively supported in iOS.

     We will use the flag images I put on my Manta server for 207 countries.

     *****

         "flag":"https://restcountries.eu/data/deu.svg",

         "regionalBlocs":[...],

         "cioc":"GER"

         }

     ]

     */

   

    /*

     *********************************************

     *   Obtaining API Search Query URL Struct   *

     *********************************************

     */

   

    // Replace space with UTF-8 encoding of space with %20

    let searchQuery = query.replacingOccurrences(of: " ", with: "%20")

   

    var apiUrl = ""

   

    switch category {

    case "Country Full Name":

        apiUrl = "https://restcountries.eu/rest/v2/name/\(searchQuery)?fullText=true"

    case "Country alpha2code":

        apiUrl = "https://restcountries.eu/rest/v2/alpha/\(searchQuery)"

    case "Country alpha3code":

        apiUrl = "https://restcountries.eu/rest/v2/alpha/\(searchQuery)"

    case "Capital City Name":

        apiUrl = "https://restcountries.eu/rest/v2/capital/\(searchQuery)"

    default:

        fatalError("Search category is out of range!")

    }

   

    /*

     searchQuery may include unrecognizable foreign characters inputted by the user,

     e.g., Côte d'Ivoire, that can prevent the creation of a URL struct from the

     given apiUrl string. Therefore, we must test it as an Optional.

    */

    var apiQueryUrlStruct: URL?

   

    if let urlStruct = URL(string: apiUrl) {

        apiQueryUrlStruct = urlStruct

    } else {

        // countryFound will have the initial values set as above

        return

    }

 

    /*

    *******************************

    *   HTTP GET Request Set Up   *

    *******************************

    */

   

    let headers = [

        "accept": "application/json",

        "cache-control": "no-cache",

        "connection": "keep-alive",

        "host": "restcountries.eu"

    ]

 

    let request = NSMutableURLRequest(url: apiQueryUrlStruct!,

                                      cachePolicy: .useProtocolCachePolicy,

                                      timeoutInterval: 10.0)

 

    request.httpMethod = "GET"

    request.allHTTPHeaderFields = headers

 

    /*

    *********************************************************************

    *  Setting Up a URL Session to Fetch the JSON File from the API     *

    *  in an Asynchronous Manner and Processing the Received JSON File  *

    *********************************************************************

    */

   

    /*

     Create a semaphore to control getting and processing API data.

     signal() -> Int    Signals (increments) a semaphore.

     wait()             Waits for, or decrements, a semaphore.

     */

    let semaphore = DispatchSemaphore(value: 0)

 

    URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in

        /*

        URLSession is established and the JSON file from the API is set to be fetched

        in an asynchronous manner. After the file is fetched, data, response, error

        are returned as the input parameter values of this Completion Handler Closure.

        */

 

        // Process input parameter 'error'

        guard error == nil else {

            // countryFound will have the initial values set as above

            semaphore.signal()

            return

        }

       

        /*

         ---------------------------------------------------------

         🔴 Any 'return' used within the completionHandler Closure

            exits the Closure; not the public function it is in.

         ---------------------------------------------------------

         */

 

        // Process input parameter 'response'. HTTP response status codes from 200 to 299 indicate success.

        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {

            // countryFound will have the initial values set as above

            semaphore.signal()

            return

        }

 

        // Process input parameter 'data'. Unwrap Optional 'data' if it has a value.

        guard let jsonDataFromApi = data else {

            // countryFound will have the initial values set as above

            semaphore.signal()

            return

        }

 

        //------------------------------------------------

        // JSON data is obtained from the API. Process it.

        //------------------------------------------------

        do {

            /*

             Foundation framework’s JSONSerialization class is used to convert JSON data

             into Swift data types such as Dictionary, Array, String, Number, or Bool.

             */

            let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi,

                               options: JSONSerialization.ReadingOptions.mutableContainers)

 

            /*

             JSON object with Attribute-Value pairs corresponds to Swift Dictionary type with

             Key-Value pairs. Therefore, we use a Dictionary to represent a JSON object

             where Dictionary Key type is String and Value type is Any (instance of any type)

             */

            var countryDataDictionary = Dictionary<String, Any>()   // Or [String: Any]()

 

            switch category {

            case "Country Full Name", "Capital City Name":

                /*

                 https://restcountries.eu/rest/v2/name/germany?fullText=true

                 https://restcountries.eu/rest/v2/capital/berlin

                 Returns an Array of one JSON object [{jsonObject}]

                 */

                if let jsonArray = jsonResponse as? [Any] {

                    if let jsonObject = jsonArray.first as? [String: Any] {

                        countryDataDictionary = jsonObject

                    } else {

                        // countryFound will have the initial values set as above

                        semaphore.signal()

                        return

                    }

                } else {

                    // countryFound will have the initial values set as above

                    semaphore.signal()

                    return

                }

               

            case "Country alpha2code", "Country alpha3code":

                /*

                 https://restcountries.eu/rest/v2/alpha/de

                 https://restcountries.eu/rest/v2/alpha/deu

                 Returns a JSON Object {jsonObject}

                 */

                if let jsonObject = jsonResponse as? [String: Any] {

                    countryDataDictionary = jsonObject

                } else {

                    // countryFound will have the initial values set as above

                    semaphore.signal()

                    return

                }

               

            default:

                fatalError("Search category is out of range!")

            }

           

            //----------------

            // Initializations

            //----------------

           

            var countryName = "", alpha2code = "", capital = "", population = 0, area = 0

            var latitude = 0.0, longitude = 0.0, currency = "", languages = "", mapDelta = 0.0

           

            //--------------------

            // Obtain Country Name

            //--------------------

 

            // "name":"Germany"

            if let nameOfCountry = countryDataDictionary["name"] as? String {

                countryName = nameOfCountry

            } else {

                // countryFound will have the initial values as set above

                semaphore.signal()

                return

            }

 

            //--------------------------

            // Obtain Country alpha2code

            //--------------------------

 

            // "alpha2Code":"DE"

            if let code = countryDataDictionary["alpha2Code"] as? String {

                alpha2code = code

            } else {

                alpha2code = "unavailable"

            }

 

            //-------------------------

            // Obtain Capital City Name

            //-------------------------

 

            // "capital":"Berlin"

            if let capitalCityName = countryDataDictionary["capital"] as? String {

                capital = capitalCityName

            } else {

                capital = "unavailable"

            }

 

            //--------------------------

            // Obtain Country Population

            //--------------------------

 

            // "population":81770900

            if let populationObtained = countryDataDictionary["population"] as? Int {

                population = populationObtained

            }

 

            //------------------------------

            // Obtain Latitude and Longitude

            //------------------------------

 

            // "latlng":[51.0,9.0]

            if let latlngArray = countryDataDictionary["latlng"] as? [Double] {

                latitude  = latlngArray[0]

                longitude = latlngArray[1]

            }

 

            //-----------------------------------------------

            // Obtain Country Total Area in Square Kilometers

            //-----------------------------------------------

 

            // "area":357114.0

            if let areaObtained = countryDataDictionary["area"] as? Double {

                area = Int(areaObtained)

            }

 

            //------------------------

            // Obtain Country Currency

            //------------------------

 

            // "currencies":[{"code":"EUR","name":"Euro","symbol":"€"}]

            if let currenciesArray = countryDataDictionary["currencies"] as? [Any] {

               

                if let currencyJsonObject = currenciesArray.first as? [String: Any] {

 

                    if let currencyName = currencyJsonObject["name"] as? String {

                        currency = currencyName

                    } else {

                        currency = "unavailable"

                    }

                }

            } else {

                currency = "unavailable"

            }

 

            //----------------------------------

            // Obtain Country Official Languages

            //----------------------------------

 

            /* "languages":[

                 {"iso639_1":"nl","iso639_2":"nld","name":"Dutch","nativeName":"Nederlands"},

                 {"iso639_1":"fr","iso639_2":"fra","name":"French","nativeName":"français"},

                 {"iso639_1":"de","iso639_2":"deu","name":"German","nativeName":"Deutsch"}

             ]

             */

            if let languagesArray = countryDataDictionary["languages"] as? [Any] {

               

                for languageJsonObject in languagesArray {

                    if let languageDictionary = languageJsonObject as? [String: Any] {

 

                        if let languageName = languageDictionary["name"] as? String {

                           

                            languages.append(languageName + ", ")

                        } else {

                            languages = "unavailable"

                        }

                    } else {

                        languages = "unavailable"

                    }

                }   // End of 'for loop'

               

                /*

                 Deleting last two characters ", " produces a substring,

                 which needs to be converted to String.

                 */

                languages = String(languages.dropLast(2))

 

            } else {

                languages = "unavailable"

            }

 

            mapDelta = countryMapDelta(area: Double(area))

 

            //----------------------------------------------------------

            // Construct a New Country Struct and Set it to countryFound

            //----------------------------------------------------------

           

            countryFound = Country(id: UUID(), name: countryName, alpha2code: alpha2code, flagImageUrl: "https://manta.cs.vt.edu/iOS/flags/\(alpha2code).png", capital: capital, population: population, area: area, languages: languages, currency: currency, latitude: latitude, longitude: longitude, delta: mapDelta, deltaUnit: "degrees")

 

        } catch {

            // countryFound will have the initial values set as above

            semaphore.signal()

            return

        }

 

        semaphore.signal()

    }).resume()

 

    /*

     The URLSession task above is set up. It begins in a suspended state.

     The resume() method starts processing the task in an execution thread.

 

     The semaphore.wait blocks the execution thread and starts waiting.

     Upon completion of the task, the Completion Handler code is executed.

     The waiting ends when .signal() fires or timeout period of 10 seconds expires.

    */

 

    _ = semaphore.wait(timeout: .now() + 10)

 

}

 

/*

 ======================================

 MARK: - Country Map Delta (Zoom Level)

 ======================================

 */

func countryMapDelta(area: Double) -> Double {

    /*

     ---------------------------------------------------------------------------------

     For maps, delta specifies north-to-south or east-to-west distance from the center

     in units of degrees or meters. Delta is also referred to as the Map Zoom Level.

     For a country map, we use the same delta value in degrees for both north-to-south

     and east-to-west distances. We determine a delta value (zoom level) according to

     the country's total area in square kilometers so that its map is properly shown.

     ---------------------------------------------------------------------------------

     */

    var delta = 0.0     // In unit of degrees

   

    switch area {

    case 1..<20000.0:

        delta = 2.0

    case 20000.0..<40000.0:

        delta = 3.0

    case 40000.0..<60000.0:

        delta = 4.0

    case 60000.0..<80000.0:

        delta = 5.0

    case 80000.0..<100000.0:

        delta = 6.0

    case 100000.0..<200000.0:

        delta = 9.0

    case 200000.0..<300000.0:

        delta = 12.0

    case 300000.0..<400000.0:

        delta = 15.0

    case 400000.0..<500000.0:

        delta = 18.0

    case 500000.0..<600000.0:

        delta = 21.0

    case 600000.0..<700000.0:

        delta = 24.0

    case 700000.0..<800000.0:

        delta = 27.0

    case 800000.0..<1000000.0:

        delta = 30.0

    case 1000000.0..<2000000.0:

        delta = 32.0

    case 2000000.0..<3000000.0:

        delta = 33.0

    case 3000000.0..<4000000.0:

        delta = 34.0

    case 4000000.0..<5000000.0:

        delta = 35.0

    case 5000000.0..<6000000.0:

        delta = 36.0

    case 6000000.0..<7000000.0:

        delta = 37.0

    case 7000000.0..<8000000.0:

        delta = 38.0

    case 8000000.0..<9000000.0:

        delta = 39.0

    case 9000000.0..<20000000.0:

        delta = 40.0

    default:

        delta = 40.0

    }

   

    return delta

}

 
