//
//  SearchResultsList.swift
//  MyContacts
//
//  Created by Gregory Cason Brinson on 12/8/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct SearchResultsList: View {

    // ❎ CoreData managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // ❎ CoreData FetchRequest returning filtered Song entities from the database
    @FetchRequest(fetchRequest: Contact.filteredContactsFetchRequest(searchCategory: searchCategory, searchQuery: searchQuery)) var filteredContacts: FetchedResults<Contact>

    var body: some View {
        if !self.filteredContacts.isEmpty {
            List {
                ForEach(self.filteredContacts) { aContact in
                    NavigationLink(destination: SearchResultDetails(contact: aContact)) {
                        SearchResultItem(contact: aContact)
                    }
                }
            }   // End of List
            .navigationBarTitle(Text("Contacts Found"), displayMode: .inline)
        } else {
            AnyView(noResultsMessage)
        }
    }
    
    var noResultsMessage: some View {
        ZStack {
            Color(red: 1.0, green: 1.0, blue: 240/255)
        VStack {
            Image(systemName: "exclamationmark.triangle")
                .imageScale(.large)
                .font(Font.title.weight(.medium))
                .foregroundColor(.red)
                .padding()

            Text("Database Search Produced No Results!\nDatabase did not return a value for the given search query!")
                .fixedSize(horizontal: false, vertical: true)   // Allow lines to wrap around
                .multilineTextAlignment(.center)
                .padding(.horizontal)
        }
        }

        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)

        //.background(Color(red: 1.0, green: 1.0, blue: 240/255))     // Ivory color
    }
}

struct SearchResultsList_Previews: PreviewProvider {
    static var previews: some View {
        SearchResultsList()
    }
}

