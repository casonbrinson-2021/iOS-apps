//
//  ContactsList.swift
//  MyContacts
//
//  Created by Gregory Cason Brinson on 12/7/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct ContactsList: View {
    
    @Environment(\.managedObjectContext) var managedObjectContext

    @FetchRequest(fetchRequest: Contact.allContactsFetchRequest()) var allContacts: FetchedResults<Contact>
    
    @EnvironmentObject var userData: UserData
    
    var body: some View {
        
        NavigationView {
            List {
                ForEach(self.allContacts) { aContact in
                    NavigationLink(destination: ContactDetails(contact: aContact)) {
                        ContactItem(contact: aContact)
                    }
                }
                .onDelete(perform: delete)
            }   // End of List

            .navigationBarTitle(Text("Contacts"), displayMode: .inline)

            // Place the Edit button on left and Add (+) button on right of the navigation bar
            .navigationBarItems(leading: EditButton(), trailing:
                NavigationLink(destination: AddContact()) {
                    Image(systemName: "plus")
                })
        }   // End of NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    
    /*
     ----------------------------
     MARK: - Delete Selected Contact
     ----------------------------
     */
    func delete(at offsets: IndexSet) {

        let contactToDelete = self.allContacts[offsets.first!]

        // CoreData Delete operation
        self.managedObjectContext.delete(contactToDelete)
        
        // CoreData Save operation
        do {
          try self.managedObjectContext.save()
        } catch {
          print("Unable to delete selected contact!")
        }
    }
    
    
}

struct ContactsList_Previews: PreviewProvider {
    static var previews: some View {
        ContactsList()
    }
}
