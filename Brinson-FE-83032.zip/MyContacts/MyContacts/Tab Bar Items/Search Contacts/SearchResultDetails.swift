//
//  SearchResultDetails.swift
//  MyContacts
//
//  Created by Gregory Cason Brinson on 12/8/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct SearchResultDetails: View {
    
    let contact: Contact
    
    @FetchRequest(fetchRequest: Contact.allContactsFetchRequest()) var allContacts: FetchedResults<Contact>

    @EnvironmentObject var userData: UserData
    
    var body: some View {
        Form {
            Section(header: Text("Name")) {
                Text("\(contact.firstName ?? "") \(contact.lastName ?? "")")
            }
            Section(header: Text("Photo")) {
                // This public function is given in UtilityFunctions.swift
                getImageFromBinaryData(binaryData: contact.photo!.contactPhoto!, defaultFilename: "DefaultContactPhoto")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(minWidth: 300, maxWidth: 500, alignment: .center)

            }
            Section(header: Text("Company Name")) {
                Text(contact.company ?? "")
            }
            Section(header: Text("Phone Number")) {
                HStack {
                    Image(systemName: "phone.circle")
                        .imageScale(.medium)
                        .font(Font.title.weight(.light))
                        .foregroundColor(.blue)
                    Text(contact.phone ?? "")
                }
            }
            Section(header: Text("Email Address")) {
                HStack {
                    Image(systemName: "envelope")
                        .imageScale(.medium)
                        .font(Font.title.weight(.light))
                        .foregroundColor(.blue)
                    Text(contact.email ?? "")
                }
            }
            Section(header: Text("Website URL")) {
                Link(destination: URL(string: contact.url ?? "")!) {
                    HStack {
                        Image(systemName: "globe")
                            .imageScale(.medium)
                            .font(Font.title.weight(.light))
                        Text("Show Contact's Website")
                    }
                }

            }
            Section(header: Text("Notes")) {
                Text(contact.notes ?? "")
            }
            Section(header: Text("Postal Address")) {
                VStack(alignment: .leading) {
                    Text(contact.addressLine1 ?? "")
                    Text(contact.addressLine2 ?? "")
                    Text("\(contact.addressCity ?? ""), \(contact.addressState ?? "") \(contact.addressZipcode ?? "")")
                    Text(contact.addressCountry ?? "")
                }
            }
        }   // End of Form
        .navigationBarTitle(Text("Contact Details"), displayMode: .inline)
        .font(.system(size: 14))
    }
}

struct SearchResultDetails_Previews: PreviewProvider {
    static var previews: some View {
        //SearchResultDetails()
        Text("Hello world")
    }
}
