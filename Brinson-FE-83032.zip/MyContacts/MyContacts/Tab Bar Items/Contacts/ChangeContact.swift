//
//  ChangeContact.swift
//  MyContacts
//
//  Created by Gregory Cason Brinson on 12/7/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct ChangeContact: View {
    
    let contact: Contact

    @FetchRequest(fetchRequest: Contact.allContactsFetchRequest()) var allContacts: FetchedResults<Contact>
    
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.managedObjectContext) var managedObjectContext

    @EnvironmentObject var userData: UserData
    
    @State private var showContactChangedAlert = false
    @State private var showNoChangesAlert = false
    
    @State private var changeFirstName = false
    @State private var changeLastName = false
    @State private var changePhone = false
    @State private var changeCompany = false
    @State private var changeEmail = false
    @State private var changeUrl = false
    @State private var changeNotes = false
    @State private var changePhoto = false
    @State private var changeAddressLine1 = false
    @State private var changeAddressLine2 = false
    @State private var changeAddressCity = false
    @State private var changeAddressState = false
    @State private var changeAddressZipcode = false
    @State private var changeAddressCountry = false
    
    @State private var firstName = ""
    @State private var lastName = ""
    @State private var company = ""
    @State private var phone = ""
    @State private var email = ""
    @State private var url = ""
    @State private var notes = ""
    @State private var addressLine1 = ""
    @State private var addressLine2 = ""
    @State private var addressCity = ""
    @State private var addressState = ""
    @State private var addressZipcode = ""
    @State private var addressCountry = ""
    
    // Contact Photo
    @State private var showImagePicker = false
    @State private var photoImageData: Data? = nil
    @State private var photoTakeOrPickIndex = 0


    var photoTakeOrPickChoices = ["Camera", "Photo Library"]
    
    var body: some View {
        Form {
            Group {
                Section(header: Text("First Name")) {
                    if self.changeFirstName == false {
                        HStack {
                            Text(contact.firstName ?? "")
                            Button(action: {
                                self.changeFirstName = true
                            }) {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    } else {
                        VStack(alignment: .center) {
                            HStack {
                                Text(contact.firstName ?? "")
                                Button(action: {
                                    self.firstName = ""
                                    self.changeFirstName = false
                                }) {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                            }
                            TextField("Change first name", text: $firstName)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.words)
                        }
                    }
                }
                Section(header: Text("Last Name")) {
                    if self.changeLastName == false {
                        HStack {
                            Text(contact.lastName ?? "")
                            Button(action: {
                                self.changeLastName = true
                            }) {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    } else {
                        VStack(alignment: .center) {
                            HStack {
                                Text(contact.lastName ?? "")
                                Button(action: {
                                    self.lastName = ""
                                    self.changeLastName = false
                                }) {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                            }
                            TextField("Change last name", text: $lastName)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.words)
                        }
                    }
                }
                Section(header: Text("Company Name")) {
                    if self.changeCompany == false {
                        HStack {
                            Text(contact.company ?? "")
                            Button(action: {
                                self.changeCompany = true
                            }) {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    } else {
                        VStack(alignment: .center) {
                            HStack {
                                Text(contact.company ?? "")
                                Button(action: {
                                    self.company = ""
                                    self.changeCompany = false
                                }) {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                            }
                            TextField("Change company name", text: $company)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.words)
                        }
                    }
                }
                Section(header: Text("Phone Number")) {
                    if self.changePhone == false {
                        HStack {
                            Text(contact.phone ?? "")
                            Button(action: {
                                self.changePhone = true
                            }) {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    } else {
                        VStack(alignment: .center) {
                            HStack {
                                Text(contact.phone ?? "")
                                Button(action: {
                                    self.phone = ""
                                    self.changePhone = false
                                }) {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                            }
                            TextField("Change phone number", text: $phone)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.none)
                        }
                    }
                }
                Section(header: Text("Email Address")) {
                    if self.changeEmail == false {
                        HStack {
                            Text(contact.email ?? "")
                            Button(action: {
                                self.changeEmail = true
                            }) {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    } else {
                        VStack(alignment: .center) {
                            HStack {
                                Text(contact.email ?? "")
                                Button(action: {
                                    self.email = ""
                                    self.changeEmail = false
                                }) {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                            }
                            TextField("Change email address", text: $email)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.none)
                        }
                    }
                }
                Section(header: Text("Website URL")) {
                    if self.changeUrl == false {
                        HStack {
                            Text(contact.url ?? "")
                            Button(action: {
                                self.changeUrl = true
                            }) {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    } else {
                        VStack(alignment: .center) {
                            HStack {
                                Text(contact.url ?? "")
                                Button(action: {
                                    self.url = ""
                                    self.changeUrl = false
                                }) {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                            }
                            TextField("Change website URL", text: $url)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.none)
                        }
                    }
                }
                Section(header: Text("Contact Notes")) {
                    if self.changeNotes == false {
                        HStack {
                            Text(contact.notes ?? "")
                            Button(action: {
                                self.changeNotes = true
                            }) {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    } else {
                        HStack {
                            Text(contact.notes ?? "")
                            Button(action: {
                                self.notes = ""
                                self.changeNotes = false
                            }) {
                                Image(systemName: "xmark.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    }
                }
                if self.changeNotes {
                    Section(header: Text("New Contact Notes"), footer:
                                Button(action: {
                                    self.dismissKeyboard()
                                }) {
                                    Image(systemName: "keyboard")
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                    }) {
                        TextEditor(text: $notes)
                            .frame(height: 100)
                            .font(.custom("Helvetica", size: 14))
                            .foregroundColor(.primary)
                            .multilineTextAlignment(.leading)
                    }
                }
                Section(header: Text("Contact Photo")) {
                    if self.changePhoto == false {
                        HStack {
                        // This public function is given in UtilityFunctions.swift
                            getImageFromBinaryData(binaryData: contact.photo!.contactPhoto!, defaultFilename: "DefaultContactPhoto")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 100, height: 100)
                            Button(action: {
                                self.changePhoto = true
                            }) {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    } else {
                        HStack {
                        // This public function is given in UtilityFunctions.swift
                            getImageFromBinaryData(binaryData: contact.photo!.contactPhoto!, defaultFilename: "DefaultContactPhoto")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 100, height: 100)
                            Button(action: {
                                self.photoImageData = nil
                                self.changePhoto = false
                            }) {
                                Image(systemName: "xmark.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    }
                }
                if self.changePhoto {
                    Section(header: Text("New Contact Photo")) {
                        VStack(alignment: .center) {
                            Picker("", selection: $photoTakeOrPickIndex) {
                                ForEach(0 ..< photoTakeOrPickChoices.count, id: \.self) {
                                    Text(self.photoTakeOrPickChoices[$0])
                                }
                            }
                            .pickerStyle(SegmentedPickerStyle())
                            .padding()

                            Button(action: {
                                self.showImagePicker = true
                            }) {
                                Text("Get Photo")
                                    .padding()
                            }
                            photoImage
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 100.0, height: 100.0)
                        }   // End of VStack
                    }
                }
            }//end of Group
            .alert(isPresented: $showContactChangedAlert, content: { self.contactChangedAlert })
            Group {
                Section(header: Text("Address Line 1")) {
                    if self.changeAddressLine1 == false {
                        HStack {
                            Text(contact.addressLine1 ?? "")
                            Button(action: {
                                self.changeAddressLine1 = true
                            }) {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    } else {
                        VStack(alignment: .center) {
                            HStack {
                                Text(contact.addressLine1 ?? "")
                                Button(action: {
                                    self.addressLine1 = ""
                                    self.changeAddressLine1 = false
                                }) {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                            }
                            TextField("Change address line 1", text: $addressLine1)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.words)
                        }
                    }
                }
                Section(header: Text("Address Line 2")) {
                    if self.changeAddressLine2 == false {
                        HStack {
                            Text(contact.addressLine2 ?? "")
                            Button(action: {
                                self.changeAddressLine2 = true
                            }) {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    } else {
                        VStack(alignment: .center) {
                            HStack {
                                Text(contact.addressLine2 ?? "")
                                Button(action: {
                                    self.addressLine2 = ""
                                    self.changeAddressLine2 = false
                                }) {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                            }
                            TextField("Change address line 2", text: $addressLine2)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.words)
                        }
                    }
                }
                Section(header: Text("City Name")) {
                    if self.changeAddressCity == false {
                        HStack {
                            Text(contact.addressCity ?? "")
                            Button(action: {
                                self.changeAddressCity = true
                            }) {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    } else {
                        VStack(alignment: .center) {
                            HStack {
                                Text(contact.addressCity ?? "")
                                Button(action: {
                                    self.addressCity = ""
                                    self.changeAddressCity = false
                                }) {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                            }
                            TextField("Change city name", text: $addressCity)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.words)
                        }
                    }
                }
                Section(header: Text("State Abbreviatino")) {
                    if self.changeAddressState == false {
                        HStack {
                            Text(contact.addressState ?? "")
                            Button(action: {
                                self.changeAddressState = true
                            }) {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    } else {
                        VStack(alignment: .center) {
                            HStack {
                                Text(contact.addressState ?? "")
                                Button(action: {
                                    self.addressState = ""
                                    self.changeAddressState = false
                                }) {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                            }
                            TextField("Change State abbreviation", text: $addressState)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.allCharacters)
                        }
                    }
                }
                Section(header: Text("Zip Code")) {
                    if self.changeAddressZipcode == false {
                        HStack {
                            Text(contact.addressZipcode ?? "")
                            Button(action: {
                                self.changeAddressZipcode = true
                            }) {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    } else {
                        VStack(alignment: .center) {
                            HStack {
                                Text(contact.addressZipcode ?? "")
                                Button(action: {
                                    self.addressZipcode = ""
                                    self.changeAddressZipcode = false
                                }) {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                            }
                            TextField("Change Zip Code", text: $addressZipcode)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.none)
                        }
                    }
                }
                Section(header: Text("Country Name")) {
                    if self.changeAddressCountry == false {
                        HStack {
                            Text(contact.addressCountry ?? "")
                            Button(action: {
                                self.changeAddressCountry = true
                            }) {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                        }
                    } else {
                        VStack(alignment: .center) {
                            HStack {
                                Text(contact.addressCountry ?? "")
                                Button(action: {
                                    self.addressCountry = ""
                                    self.changeAddressCountry = false
                                }) {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                            }
                            TextField("Change country name", text: $addressCountry)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.allCharacters)
                        }
                    }
                }
            }//end of Group
        }   // End of Form
        .navigationBarTitle(Text("Change Contact"), displayMode: .inline)
        .font(.system(size: 14))
        .disableAutocorrection(true)
        .alert(isPresented: $showNoChangesAlert, content: { self.noChangesAlert })
        .navigationBarItems(trailing:
            Button(action: {
                if self.changesMade() {
                    self.saveChanges()
                    self.showContactChangedAlert = true
                } else {
                    self.showNoChangesAlert = true
                }
            }) {
                Text("Save")
            })
        .sheet(isPresented: self.$showImagePicker) {
            PhotoCaptureView(showImagePicker: self.$showImagePicker,
                             photoImageData: self.$photoImageData,
                             cameraOrLibrary: self.photoTakeOrPickChoices[self.photoTakeOrPickIndex])
        }
    }
    
    //gets the image that the user decides to use
    var photoImage: Image {
        if let imageData = self.photoImageData {
            // The public function is given in UtilityFunctions.swift
            let imageView = getImageFromBinaryData(binaryData: imageData, defaultFilename: "DefaultContactPhoto")
            return imageView
        } else {
            return Image("DefaultContactPhoto")
        }
    }
    
    /*
     Function ot dismiss keyboard
     */
    func dismissKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    //noChangesAlert
    var noChangesAlert: Alert {
        Alert(title: Text("No Changes Saved!"),
              message: Text("You did not make any changes!"),
              dismissButton: .default(Text("OK")) {
                  // Dismiss this View and go back
                  self.presentationMode.wrappedValue.dismiss()
            })
    }
    
    //changedContactalert
    var contactChangedAlert: Alert {
        Alert(title: Text("Changes Saved!"),
              message: Text("Your changes have been succesfully saved to the database."),
              dismissButton: .default(Text("OK")) {
                  // Dismiss this View and go back
                  self.presentationMode.wrappedValue.dismiss()
            })
    }
    
    //if changes were made
    func changesMade() -> Bool {

        if self.firstName.isEmpty && self.lastName.isEmpty && self.company.isEmpty && self.phone.isEmpty && self.email.isEmpty && self.url.isEmpty && self.notes.isEmpty && self.addressLine1.isEmpty && self.addressLine2.isEmpty && self.addressCity.isEmpty && self.addressState.isEmpty && self.addressZipcode.isEmpty && self.addressCountry.isEmpty && self.photoImageData == nil {
            return false
        }
        return true
    }
    
    //saves the changes to the contact
    func saveChanges() {
        if self.firstName != "" {
            contact.firstName = self.firstName
        }
        if self.lastName != "" {
            contact.lastName = self.lastName
        }
        if self.company != "" {
            contact.company = self.company
        }
        if self.phone != "" {
            contact.phone = self.phone
        }
        if self.email != "" {
            contact.email = self.email
        }
        if self.url != "" {
            contact.url = self.url
        }
        if self.notes != "" {
            contact.notes = self.notes
        }
        if self.addressLine1 != "" {
            contact.addressLine1 = self.addressLine1
        }
        if self.addressLine2 != "" {
            contact.addressLine2 = self.addressLine2
        }
        if self.addressCity != "" {
            contact.addressCity = self.addressCity
        }
        if self.addressState != "" {
            contact.addressState = self.addressState
        }
        if self.addressZipcode != "" {
            contact.addressZipcode = self.addressZipcode
        }
        if self.addressCountry != "" {
            contact.addressCountry = self.addressCountry
        }
        
        if self.photoImageData != nil {
            if let imageData = self.photoImageData {
                contact.photo!.contactPhoto! = imageData
            } else {
                let photoUIImage = UIImage(named: "DefaultContactPhoto")
                let photoData = photoUIImage?.jpegData(compressionQuality: 1.0)
                contact.photo!.contactPhoto! = photoData!
            }
        }

        /*
         ==================================
         Save Changes to Core Data Database
         ==================================
        */

        // ❎ CoreData Save operation
        do {
            try self.managedObjectContext.save()
        } catch {
            return
        }
    }   // End of function
    
}

struct ChangeContact_Previews: PreviewProvider {
    static var previews: some View {
        Text("Hello world")
    }
}
