//
//  ContentView.swift
//  HelloWorld
//
//  Created by CS3714 on 8/28/20.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        ZStack {    //background
            Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
            VStack { //foreground
                Text("Hello, world!")
                    .padding()
                    .font(.largeTitle)
                HStack {
                    Text("Virginia Tech is ")
                        .font(.system(size: 24))
                        .foregroundColor(.red)
                    Image(systemName: "1.circle")
                        .imageScale(.large)
                        .font(Font.title.weight(.regular))
                        .foregroundColor(.blue)
                }   //End of HStack
            }   //End of VStack
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
