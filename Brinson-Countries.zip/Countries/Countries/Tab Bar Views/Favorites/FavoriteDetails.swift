
//

//  FavoriteDetails.swift

//  Countries

//

//  Created by Cason Brinson on 9/17/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.

//

 

import SwiftUI

import MapKit

 

struct FavoriteDetails: View {

   

    // Input Parameter

    let country: Country

   

    var body: some View {

        // A Form cannot have more than 10 Sections.

        // Group the Sections if more than 10.

        Form {

            Group {

                Section(header: Text("Country Name"), footer: Text("Name of Favorite Country").italic()) {

                    Text(country.name)

                }

                Section(header: Text("Country Flag Image"), footer: Text("Flag Image Obtained from Manta Server").italic()) {

                    // Public function getImageFromUrl is given in UtilityFunctions.swift

                    getImageFromUrl(url: country.flagImageUrl, defaultFilename: "ImageUnavailable")

                        .resizable()

                        .aspectRatio(contentMode: .fit)

                        .frame(minWidth: 300, maxWidth: 500, alignment: .center)

                }

                Section(header: Text("Country alpha2code"), footer: Text("ISO Standard Two-Letter Country Code").italic()) {

                    Text(country.alpha2code)

                }

                Section(header: Text("Country Map"), footer: Text("Country Map Provided by Apple Maps").italic()) {

                    NavigationLink(destination: countryMap) {

                        HStack {

                            Image(systemName: "map.fill")

                                .imageScale(.medium)

                                .font(Font.title.weight(.regular))

                                .foregroundColor(.blue)

                            Text("Show Country Map")

                                .font(.system(size: 16))

                        }

                        .frame(minWidth: 300, maxWidth: 500, alignment: .leading)

                    }

                }

                Section(header: Text("Capital City"), footer: Text("Name of Capital City of \(country.name)").italic()) {

                    Text(country.capital)

                }

            }

            Group {

                Section(header: Text("Population"), footer: Text("Population of \(country.name)").italic()) {

                    countryPopulation

                }

                Section(header: Text("Total Area in Square Kilometers"), footer: Text("Square Kilometers of \(country.name)").italic()) {

                    countryTotalArea

                }

                Section(header: Text("Languages"), footer: Text("Languages Spoken in \(country.name)").italic()) {

                    Text(country.languages)

                }

                Section(header: Text("Currency"), footer: Text("Currency of \(country.name)").italic()) {

                    Text(country.currency)

                }

                Section(header: Text("Center Geolocation Latitude")) {

                    Text(String(country.latitude))

                }

                Section(header: Text("Center Geolocation Longitude")) {

                    Text(String(country.longitude))

                }

            }

 

        }   // End of Form

            .navigationBarTitle(Text("Country Details"), displayMode: .inline)

            .font(.system(size: 14))

       

    }   // End of body

   

    var countryMap: some View {

       

        return AnyView(MapView(mapType: MKMapType.standard, latitude: country.latitude, longitude: country.longitude, delta: country.delta, deltaUnit: country.deltaUnit, annotationTitle: country.name, annotationSubtitle: country.capital)

                .navigationBarTitle(Text(country.name), displayMode: .inline)

                .edgesIgnoringSafeArea(.all) )

    }

   

    var countryPopulation: Text {

        let populationInt = country.population

       

        // Add thousand separators to populationInt

        let numberFormatter = NumberFormatter()

        numberFormatter.usesGroupingSeparator = true

        numberFormatter.groupingSize = 3

       

        let populationString = numberFormatter.string(from: populationInt as NSNumber)

        return Text(populationString!)

    }

   

    var countryTotalArea: Text {

        // Total area is in Square Kilometers

        let areaInt = country.area

       

        // Add thousand separators to areaInt

        let numberFormatter = NumberFormatter()

        numberFormatter.usesGroupingSeparator = true

        numberFormatter.groupingSize = 3

       

        let areaString = numberFormatter.string(from: areaInt as NSNumber)

        return Text(areaString!)

    }

}

 

struct FavoriteDetails_Previews: PreviewProvider {

    static var previews: some View {

        FavoriteDetails(country: countryStructList[0])

    }

}

 
