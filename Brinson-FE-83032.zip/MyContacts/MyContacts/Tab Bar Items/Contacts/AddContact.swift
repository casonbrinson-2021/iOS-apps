//
//  AddContact.swift
//  MyContacts
//
//  Created by Gregory Cason Brinson on 12/7/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI
import CoreData

struct AddContact: View {
    
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.managedObjectContext) var managedObjectContext

    @State private var showContactAddedAlert = false
    @State private var showInputDataMissingAlert = false

    @State private var firstName = ""
    @State private var lastName = ""
    @State private var company = ""
    @State private var phone = ""
    @State private var email = ""
    @State private var url = ""
    @State private var notes = ""
    @State private var addressLine1 = ""
    @State private var addressLine2 = ""
    @State private var addressCity = ""
    @State private var addressState = ""
    @State private var addressZipcode = ""
    @State private var addressCountry = ""
   

    // Contact Photo
    @State private var showImagePicker = false
    @State private var photoImageData: Data? = nil
    @State private var photoTakeOrPickIndex = 0


    var photoTakeOrPickChoices = ["Camera", "Photo Library"]
    
    var body: some View {
        Form {
            Group {
                Section(header: Text("First Name")) {
                    HStack {
                        TextField("Enter first name", text: $firstName)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .autocapitalization(.words)
                        Button(action: {
                            self.firstName = ""
                        }) {
                            Image(systemName: "xmark.square")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }//end of Section
                Section(header: Text("Last Name")) {
                    HStack {
                        TextField("Enter last name", text: $lastName)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .autocapitalization(.words)
                        Button(action: {
                            self.lastName = ""
                        }) {
                            Image(systemName: "xmark.square")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }//end of Section
                Section(header: Text("Company Name")) {
                    HStack {
                        TextField("Enter company name", text: $company)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .autocapitalization(.words)
                        Button(action: {
                            self.company = ""
                        }) {
                            Image(systemName: "xmark.square")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }//end of Section
                Section(header: Text("Phone Number")) {
                    HStack {
                        TextField("Enter phone number", text: $phone)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .autocapitalization(.none)
                        Button(action: {
                            self.phone = ""
                        }) {
                            Image(systemName: "xmark.square")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }//end of Section
                Section(header: Text("Email Address")) {
                    HStack {
                        TextField("Enter email address", text: $email)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .autocapitalization(.none)
                        Button(action: {
                            self.email = ""
                        }) {
                            Image(systemName: "xmark.square")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }//end of Section
                Section(header: Text("Website URL")) {
                    HStack {
                        TextField("Enter website URL", text: $url)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .autocapitalization(.none)
                        Button(action: {
                            self.url = ""
                        }) {
                            Image(systemName: "xmark.square")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }//end of Section
                
                Section(header: Text("Contact Notes"), footer:
                    Button(action: {
                        self.dismissKeyboard()
                    }) {
                        Image(systemName: "keyboard")
                            .font(Font.title.weight(.light))
                            .foregroundColor(.blue)
                        }
                    ){
                        TextEditor(text: $notes)
                            .frame(height: 100)
                            .font(.custom("Helvetica", size: 14))
                            .foregroundColor(.primary)
                            .multilineTextAlignment(.leading)
                }//end of Section

                Section(header: Text("Add Contact Photo")) {
                    VStack {
                        Picker("", selection: $photoTakeOrPickIndex) {
                            ForEach(0 ..< photoTakeOrPickChoices.count, id: \.self) {
                                Text(self.photoTakeOrPickChoices[$0])
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        .padding()

                        Button(action: {
                            self.showImagePicker = true
                        }) {
                            Text("Get Photo")
                                .padding()
                        }
                    }   // End of VStack
                }
                Section(header: Text("Contact Photo")) {
                    photoImage
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100.0, height: 100.0)
                }//end of Section
                Section(header: Text("Address Line 1")) {
                    HStack {
                        TextField("Enter address line 1", text: $addressLine1)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        Button(action: {
                            self.addressLine1 = ""
                        }) {
                            Image(systemName: "xmark.square")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }//end of Section
            }//end of group
            .alert(isPresented: $showContactAddedAlert, content: { self.contactAddedAlert })
            Group {
                Section(header: Text("Address Line 2")) {
                    HStack {
                        TextField("Enter address line 2", text: $addressLine2)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        Button(action: {
                            self.addressLine2 = ""
                        }) {
                            Image(systemName: "xmark.square")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }//end of Section
                Section(header: Text("City Name")) {
                    HStack {
                        TextField("Enter city Name", text: $addressCity)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .autocapitalization(.words)
                        Button(action: {
                            self.addressCity = ""
                        }) {
                            Image(systemName: "xmark.square")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }//end of Section
                Section(header: Text("State Abbreviation")) {
                    HStack {
                        TextField("Enter State abbreviation", text: $addressState)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .autocapitalization(.allCharacters)
                        Button(action: {
                            self.addressState = ""
                        }) {
                            Image(systemName: "xmark.square")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }//end of Section
                Section(header: Text("Zip Code")) {
                    HStack {
                        TextField("Enter zip code", text: $addressZipcode)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .autocapitalization(.none)
                        Button(action: {
                            self.addressZipcode = ""
                        }) {
                            Image(systemName: "xmark.square")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }//end of Section
                Section(header: Text("Country Name")) {
                    HStack {
                        TextField("Enter country name", text: $addressCountry)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .autocapitalization(.allCharacters)
                        Button(action: {
                            self.addressCountry = ""
                        }) {
                            Image(systemName: "xmark.square")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }//end of Section
            }//end of Group
        }//end of Form
        .disableAutocorrection(true)
        .font(.system(size: 14))
        .alert(isPresented: $showInputDataMissingAlert, content: { self.inputDataMissingAlert })

        .navigationBarTitle(Text("Add Contact"), displayMode: .inline)
        .navigationBarItems(trailing:
            Button(action: {
                if self.inputDataValidated() {
                    self.saveNewContact()
                    self.showContactAddedAlert = true
                } else {
                    self.showInputDataMissingAlert = true
                }
            }) {
                Text("Save")
            })
        .sheet(isPresented: self.$showImagePicker) {
            PhotoCaptureView(showImagePicker: self.$showImagePicker,
                             photoImageData: self.$photoImageData,
                             cameraOrLibrary: self.photoTakeOrPickChoices[self.photoTakeOrPickIndex])
        }
    }   // End of body

    var photoImage: Image {
        if let imageData = self.photoImageData {
            // The public function is given in UtilityFunctions.swift
            let imageView = getImageFromBinaryData(binaryData: imageData, defaultFilename: "DefaultContactPhoto")
            return imageView
        } else {
            return Image("DefaultContactPhoto")
        }
    }
    
    /*
     ------------------------
     MARK: - Contact Added Alert
     ------------------------
     */
    var contactAddedAlert: Alert {
        Alert(title: Text("Contact Added!"),
              message: Text("New contact is added to your Contacts list."),
              dismissButton: .default(Text("OK")) {
                  // Dismiss this View and go back
                  self.presentationMode.wrappedValue.dismiss()
            })
    }

    /*
     --------------------------------
     MARK: - Input Data Missing Alert
     --------------------------------
     */
    var inputDataMissingAlert: Alert {
        Alert(title: Text("Missing Input Data!"),
              message: Text("Required Data: first name, last name, phone, email, address line 1, city, and country."),
              dismissButton: .default(Text("OK")) )
    }

    /*
     -----------------------------
     MARK: - Input Data Validation
     -----------------------------
     */
    func inputDataValidated() -> Bool {
        if self.firstName.isEmpty || self.lastName.isEmpty || self.phone.isEmpty || self.addressLine1.isEmpty || self.addressCity.isEmpty || self.addressCountry.isEmpty {
            return false
        }
        return true
    }
    
    /*
     Function ot dismiss keyboard
     */
    func dismissKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }

    /*
     ---------------------
     MARK: - Save New Contact
     ---------------------
     */
    func saveNewContact() {
        /*
         =====================================================
         Create an instance of the Song Entity and dress it up
         =====================================================
        */

        // ❎ Create a new Song entity in CoreData managedObjectContext
        let newContact = Contact(context: self.managedObjectContext)

        // ❎ Dress up the new Song entity
        newContact.firstName = self.firstName
        newContact.lastName = self.lastName
        newContact.company = self.company
        newContact.phone = self.phone
        newContact.email = self.email
        newContact.url = self.url
        newContact.notes = self.notes
        newContact.addressLine1 = self.addressLine1
        newContact.addressLine2 = self.addressLine2
        newContact.addressCity = self.addressCity
        newContact.addressState = self.addressState
        newContact.addressZipcode = self.addressZipcode
        newContact.addressCountry = self.addressCountry

        /*
         ======================================================
         Create an instance of the Photo Entity and dress it up
         ======================================================
        */

        // ❎ Create a new Photo entity in CoreData managedObjectContext
        let newPhoto = Photo(context: self.managedObjectContext)

        // ❎ Dress up the new Photo entity
        if let imageData = self.photoImageData {
            newPhoto.contactPhoto = imageData
        } else {
            // Obtain the album cover default image from Assets.xcassets as UIImage
            let photoUIImage = UIImage(named: "DefaultContactPhoto")

            // Convert photoUIImage to data of type Data (Binary Data) in JPEG format with 100% quality
            let photoData = photoUIImage?.jpegData(compressionQuality: 1.0)

            // Assign photoData to Core Data entity attribute of type Data (Binary Data)
            newPhoto.contactPhoto = photoData!
        }

        /*
         ==============================
         Establish Entity Relationships
         ==============================
        */

        // Establish One-to-One Relationship between Song and Photo
        newContact.photo = newPhoto
        newPhoto.contact = newContact

        /*
         =============================================
         MARK: - ❎ Save Changes to Core Data Database
         =============================================
         */

        do {
            try self.managedObjectContext.save()
        } catch {
            return
        }
    }   // End of function
}

struct AddContact_Previews: PreviewProvider {
    static var previews: some View {
        AddContact()
    }
}
