
//

//  ContentView.swift

//  Countries

//

//  Created by Cason Brinson on 9/17/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.

//

 

import SwiftUI

 

struct ContentView: View {

    var body: some View {

        TabView {

            Home()

                .tabItem {

                    Image(systemName: "house.fill")

                    Text("Home")

                }

            FavoritesList()

                .tabItem {

                    Image(systemName: "star.fill")

                    Text("Favorites")

                }

            FlagsGrid()

                .tabItem {

                    Image(systemName: "square.grid.3x3.fill")

                    Text("Flags Grid")

                }

            SearchCountry()

                .tabItem {

                    Image(systemName: "magnifyingglass.circle.fill")

                    Text("Search")

                }

            CurrencyConverter()

                .tabItem {

                    Image(systemName: "arrow.right.arrow.left.circle.fill")

                    Text("Currency")

                }

        }   // End of TabView

            .font(.headline)

            .imageScale(.medium)

            .font(Font.title.weight(.regular))

    }

}

 

struct ContentView_Previews: PreviewProvider {

    static var previews: some View {

        ContentView().environmentObject(UserData())

    }

}

 
