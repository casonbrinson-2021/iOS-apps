
//

//  SearchCountry.swift

//  Countries

//

//  Created by Cason Brinson on 9/17/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.

//

 

import SwiftUI

 

struct SearchCountry: View {

   

    @State private var searchFieldValue = ""

    @State private var showMissingInputDataAlert = false

    @State private var searchCompleted = false

   

    let searchCategories = ["Country Full Name", "Capital City Name", "Country alpha2code", "Country alpha3code"]

    @State private var selectedIndex = 1

    

    var body: some View {

        NavigationView {

            ZStack {

                Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)

            Form {

                Section(header: Text("Select Search Category")) {

                    Picker("", selection: $selectedIndex) {

                        ForEach(0 ..< searchCategories.count, id: \.self) {

                            Text(self.searchCategories[$0])

                        }

                    }

                    .pickerStyle(WheelPickerStyle())

                    .frame(minWidth: 300, maxWidth: 500, alignment: .center)

                }

                Section(header: Text("Enter a \(searchCategories[selectedIndex])")) {

                    HStack {

                        TextField("Enter Search Query", text: $searchFieldValue)

                            .textFieldStyle(RoundedBorderTextFieldStyle())

                            .autocapitalization(self.selectedIndex <= 1 ? .words : .allCharacters)

                            .disableAutocorrection(true)

                       

                        // Button to clear the text field

                        Button(action: {

                            self.searchFieldValue = ""

                            self.showMissingInputDataAlert = false

                            self.searchCompleted = false

                        }) {

                            Image(systemName: "clear")

                                .imageScale(.medium)

                                .font(Font.title.weight(.regular))

                        }

                       

                    }   // End of HStack

                        .frame(minWidth: 300, maxWidth: 500)

                }

               

                Section(header: Text("Search Country")) {

                    HStack {

                        Button(action: {

                            if self.inputDataValidated() {

                                self.searchApi()

                                self.searchCompleted = true

                            } else {

                                self.showMissingInputDataAlert = true

                            }

                        }) {

                            Text(self.searchCompleted ? "Search Completed" : "Search")

                        }

                        .frame(width: 240, height: 36, alignment: .center)

                        .background(

                            RoundedRectangle(cornerRadius: 16)

                                .strokeBorder(Color.black, lineWidth: 1)

                        )

                    }   // End of HStack

                }

               

                if searchCompleted {

                    Section(header: Text("Show Details of the Country Found")) {

                        NavigationLink(destination: showSearchResults) {

                            HStack {

                                Image(systemName: "list.bullet")

                                    .imageScale(.medium)

                                    .font(Font.title.weight(.regular))

                                    .foregroundColor(.blue)

                                Text("Show Country Details")

                                    .font(.system(size: 16))

                            }

                        }

                        .frame(minWidth: 300, maxWidth: 500)

                    }

                }

               

            }   // End of Form

                .navigationBarTitle(Text("Search a Country"), displayMode: .inline)

                .alert(isPresented: $showMissingInputDataAlert, content: { self.missingInputDataAlert })

               

            }   // End of ZStack

           

        }   // End of NavigationView

            .customNavigationViewStyle()  // Given in NavigationStyle.swift

       

    }   // End of body

   

    /*

     ------------------

     MARK: - Search API

     ------------------

     */

    func searchApi() {

        // Remove spaces, if any, at the beginning and at the end of the entered search query string

        let queryTrimmed = self.searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)

       

        // Public function obtainCountryDataFromApi is given in CountryApiData.swift

        obtainCountryDataFromApi(category: searchCategories[selectedIndex], query: queryTrimmed)

    }

   

    /*

     ---------------------------

     MARK: - Show Search Results

     ---------------------------

     */

    var showSearchResults: some View {

       

        // Global variable countryFound is given in CountryApiData.swift

        if countryFound.name.isEmpty {

            return AnyView(notFoundMessage)

        }

       

        return AnyView(SearchResults())

    }

   

    /*

     ---------------------------------

     MARK: - Country Not Found Message

     ---------------------------------

     */

    var notFoundMessage: some View {

        VStack {

            Image(systemName: "exclamationmark.triangle")

                .imageScale(.large)

                .font(Font.title.weight(.medium))

                .foregroundColor(.red)

                .padding()

            Text("No Country Found!\n\nThe entered query \(self.searchFieldValue) under category \(searchCategories[selectedIndex]) did not return a country from the API! Please enter another search query.")

                .fixedSize(horizontal: false, vertical: true)   // Allow lines to wrap around

                .multilineTextAlignment(.center)

                .padding()

        }

        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)

        .background(Color(red: 1.0, green: 1.0, blue: 240/255))     // Ivory color

    }

   

    /*

     --------------------------------

     MARK: - Missing Input Data Alert

     --------------------------------

     */

    var missingInputDataAlert: Alert {

        Alert(title: Text("Country Search Field is Empty!"),

              message: Text("Please enter a search query!"),

              dismissButton: .default(Text("OK")) )

        /*

         Tapping OK resets @State var showMissingInputDataAlert to false.

         */

    }

   

    /*

     -----------------------------

     MARK: - Input Data Validation

     -----------------------------

     */

    func inputDataValidated() -> Bool {

       

        // Remove spaces, if any, at the beginning and at the end of the entered search query string

        let queryTrimmed = self.searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)

       

        if queryTrimmed.isEmpty {

            return false

        }

        return true

    }

   

}

 

struct SearchCountry_Previews: PreviewProvider {

    static var previews: some View {

        SearchCountry()

    }

}

 

 
