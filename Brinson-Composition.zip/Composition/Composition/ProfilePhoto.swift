//
//  ProfilePhoto.swift
//  Composition
//
//  Created by Cason Brinson on 8/27/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.

import SwiftUI

struct ProfilePhoto: View {
    //input parameter
    let filename: String
    
    
    var body: some View {
        Image(filename)
            .resizable()    //adding a modifier to the image
            .frame(width: 100, height: 100)
            .clipShape(Circle())
            .overlay(
                Circle().stroke(Color.white, lineWidth: 1)
            )
            .shadow(radius: 5)
            .padding()
    }
}

struct ProfilePhoto_Previews: PreviewProvider {
    static var previews: some View {
        ProfilePhoto(filename: "OsmanBalci")
    }
}
