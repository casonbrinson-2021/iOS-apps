//
//  CurrentDateAndTime.swift
//  Composition
//
//  Created by CS3714 on 9/2/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.
//

import SwiftUI

struct CurrentDateAndTime: View {
    var body: some View {
        VStack {
            HStack {
                //Calender icon in Apple SF Symbols
                Image(systemName: "calendar")
                    .imageScale(.medium)
                    .font(Font.title.weight(.regular))
                
                Text("Current Date and time")
                    .font(.system(size: 18, weight: .light, design: .serif))
                    .italic()
            }
            .padding(.bottom, 10)
            
            //Date() returns current date and time, independent of any calender or time zone.
            Text("\(Date())")
                //Allow current date and time to wrap around if it does not fit
                .fixedSize(horizontal: false, vertical: true)
                .foregroundColor(Color(red:128.255, green: 0.0, blue: 0.0)) //maroon
                .multilineTextAlignment(.center)
                .padding(.horizontal, 10)
        }
    }
}

struct CurrentDateAndTime_Previews: PreviewProvider {
    static var previews: some View {
        CurrentDateAndTime()
    }
}
