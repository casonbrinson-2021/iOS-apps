//
//  ContentView.swift
//  MyContacts
//
//  Created by Gregory Cason Brinson on 12/7/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            ContactsList()
                .tabItem {
                    Image(systemName: "rectangle.stack.person.crop.fill")
                    Text("Contacts")
                }
            SearchContacts()
                .tabItem {
                    Image(systemName: "magnifyingglass.circle.fill")
                    Text("Search Contacts")
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
