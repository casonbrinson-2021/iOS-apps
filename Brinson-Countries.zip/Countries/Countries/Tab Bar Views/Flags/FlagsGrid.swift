
//

//  FlagsGrid.swift

//  Countries

//

//  Created by Cason Brinson on 9/17/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.

//

 

import SwiftUI

 

fileprivate var selectedCountry = countryStructList[0]

 

struct FlagsGrid: View {

   

    // Subscribe to changes in UserData

    @EnvironmentObject var userData: UserData

   

    @State private var showCountryInfoAlert = false

   

    // Fit as many images per row as possible with minimum image width of 100 points each.

    // spacing defines spacing between columns

    let columns = [ GridItem(.adaptive(minimum: 100), spacing: 3) ]

   

    var body: some View {

        ScrollView {

            // spacing defines spacing between rows

            LazyVGrid(columns: columns, spacing: 3) {

                // 🔴 Specifying id: \.self is critically important to prevent photos being listed as out of order

                ForEach(self.userData.countriesList, id: \.self) { country in

                    // Public function getImageFromUrl is given in UtilityFunctions.swift

                    getImageFromUrl(url: country.flagImageUrl, defaultFilename: "ImageUnavailable")

                        .resizable()

                        .scaledToFit()

                        .onTapGesture {

                            selectedCountry = country

                            self.showCountryInfoAlert = true

                        }

                }

            }   // End of LazyVGrid

                .padding()

           

        }   // End of ScrollView

            .alert(isPresented: $showCountryInfoAlert, content: { self.countryInfoAlert })

    }

   

    var countryInfoAlert: Alert {

        Alert(title: Text(selectedCountry.name),

              message: Text("Capital City: \(selectedCountry.capital)\nPopulation: \(self.countryPopulation(country: selectedCountry))\nLanguages: \(selectedCountry.languages)\nCurrency: \(selectedCountry.currency)"),

              dismissButton: .default(Text("OK")) )

    }

   

    func countryPopulation(country: Country) -> String {

        let populationInt = country.population

       

        // Add thousand separators to populationInt

        let numberFormatter = NumberFormatter()

        numberFormatter.usesGroupingSeparator = true

        numberFormatter.groupingSize = 3

       

        let populationString = numberFormatter.string(from: populationInt as NSNumber)

        return populationString!

    }

   

}   // End of FlagsGrid struct

 

struct FlagsGrid_Previews: PreviewProvider {

    static var previews: some View {

        FlagsGrid()

    }

}

 
