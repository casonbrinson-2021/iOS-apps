
//

//  FavoritesList.swift

//  Countries

//

//  Created by Cason Brinson on 9/17/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.

//

 

import SwiftUI

 

struct FavoritesList: View {

   

    // Subscribe to changes in UserData

    @EnvironmentObject var userData: UserData

   

    @State private var searchItem = ""

   

    var body: some View {

        NavigationView {

            List {

                SearchBar(searchItem: $searchItem, placeholder: "Search Countries")

               

                ForEach(userData.searchableOrderedCountriesList.filter {self.searchItem.isEmpty ? true : $0.localizedStandardContains(self.searchItem)}, id: \.self)

                { item in

                    NavigationLink(destination: FavoriteDetails(country: self.searchItemCountry(searchListItem: item)))

                    {

                        FavoriteItem(country: self.searchItemCountry(searchListItem: item))

                    }

                }

                .onDelete(perform: delete)

                .onMove(perform: move)

               

            }   // End of List

            .navigationBarTitle(Text("Favorites"), displayMode: .inline)

           

            // Place the Edit button on left of the navigation bar

            .navigationBarItems(leading: EditButton())

           

        }   // End of NavigationView

            .customNavigationViewStyle()  // Given in NavigationStyle.swift

    }

   

    func searchItemCountry(searchListItem: String) -> Country {

        /*

         searchListItem = "id|name|alpha2code|capital|languages|currency"

         country id = searchListItem.components(separatedBy: "|")[0]

         */

        // Find the index number of countriesList matching the country attribute 'id'

        let index = userData.countriesList.firstIndex(where: {$0.id.uuidString == searchListItem.components(separatedBy: "|")[0]})!

       

        return userData.countriesList[index]

    }

   

    /*

     -------------------------------

     MARK: - Delete Selected Country

     -------------------------------

     */

    func delete(at offsets: IndexSet) {

        /*

        'offsets.first' is an unsafe pointer to the index number of the array element

        to be deleted. It is nil if the array is empty. Process it as an optional.

        */

        if let index = offsets.first {

            userData.countriesList.remove(at: index)

            userData.searchableOrderedCountriesList.remove(at: index)

        }

        // Set the global variable point to the changed list

        countryStructList = userData.countriesList

       

        // Set the global variable point to the changed list

        orderedSearchableCountriesList = userData.searchableOrderedCountriesList

    }

   

    /*

     -----------------------------

     MARK: - Move Selected Country

     -----------------------------

     */

    func move(from source: IndexSet, to destination: Int) {

 

        userData.countriesList.move(fromOffsets: source, toOffset: destination)

        userData.searchableOrderedCountriesList.move(fromOffsets: source, toOffset: destination)

       

        // Set the global variable point to the changed list

        countryStructList = userData.countriesList

       

        // Set the global variable point to the changed list

        orderedSearchableCountriesList = userData.searchableOrderedCountriesList

    }

}

 

struct FavoritesList_Previews: PreviewProvider {

    static var previews: some View {

        FavoritesList()

    }

}

 
