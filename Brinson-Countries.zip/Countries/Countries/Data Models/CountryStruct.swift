
//

//  CountryStruct.swift

//  Countries

//
//  Created by Cason Brinson on 9/17/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.

//

 

import SwiftUI

 

struct Country: Hashable, Codable, Identifiable {

   

    var id: UUID        // Storage Type: String, Use Type (format): UUID

    var name: String

    var alpha2code: String

    var flagImageUrl: String

    var capital: String

    var population: Int

    var area: Int           // In square kilometers

    var languages: String

    var currency: String

    var latitude: Double

    var longitude: Double

    var delta: Double

    var deltaUnit: String

}

 

/*

 We create the Country structure above to represent a country

 JSON object with exactly the same attribute names.

 {

     "id": "4055D506-91C6-42F6-9AF3-715882650837",

     "name": "Argentina",

     "alpha2code": "AR",

     "flagImageUrl": "https://manta.cs.vt.edu/iOS/flags/ar.png",

     "capital": "Buenos Aires",

     "population": 45195774,

     "area": 2780400,

     "languages": "Spanish, Guaraní",

     "currency": "Argentine peso",

     "latitude": -38.416097,

     "longitude": -63.616672,

     "delta": 33.0,

     "deltaUnit": "degrees"

 }

 */

 
