//
//  SearchContacts.swift
//  MyContacts
//
//  Created by Gregory Cason Brinson on 12/7/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI
import CoreData

var searchCategory = ""
var searchQuery = ""

struct SearchContacts: View {
    
    let searchCategoriesList = ["All", "First Name", "Last Name", "Company Name", "Notes", "City Name", "State Abbreviation", "Country Name"]
    @State private var selectedSearchCategoryIndex = 2
    @State private var searchFieldValue = ""
    
    var body: some View {
        NavigationView {
        Form {
            Section() {
                HStack {
                    Spacer()
                    Image("SearchDatabase")
                        .resizable()
                        .frame(maxWidth: 100, maxHeight: 100)
                    Spacer()
                }
            }
            Section(header: Text("Select a Search Category")) {
                //picker
                Picker("", selection: $selectedSearchCategoryIndex) {
                    ForEach(0 ..< searchCategoriesList.count, id: \.self) {
                        Text(self.searchCategoriesList[$0])
                    }
                }
                .pickerStyle(WheelPickerStyle())
                .frame(minWidth: 300, maxWidth: 500, alignment: .leading)
            }
            Section(header: Text("Search Query Under Selected Category")) {
                HStack {
                    TextField("Enter Search Query", text: $searchFieldValue)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .autocapitalization(.none)
                    Button(action: {
                        self.searchFieldValue = ""
                    }) {
                        Image(systemName: "xmark.square")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                    }
                }
            }
            Section(header: Text("Show Search Results")) {
                //change this to showSearchResults() function that you need to define
                NavigationLink(destination: showSearchResults()) {
                    HStack {
                        Image(systemName: "list.bullet")
                            .imageScale(.medium)
                        Text("Show Search Results")
                    }
                }
            }
        }//end of Form
        .navigationBarTitle(Text("Search Core Data Database"), displayMode: .inline)
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }//end of Body
    
    func showSearchResults() -> some View {

        let queryTrimmed = self.searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        if (queryTrimmed.isEmpty) {
            return AnyView(missingSearchQueryMessage)
        }
        searchCategory = self.searchCategoriesList[self.selectedSearchCategoryIndex]
        searchQuery = self.searchFieldValue
        
        return AnyView(SearchResultsList())
    }//end of Function
    
    var missingSearchQueryMessage: some View {
        ZStack {
            Color(red: 1.0, green: 1.0, blue: 240/255)
        VStack {
            Image(systemName: "exclamationmark.triangle")
                .imageScale(.large)
                .font(Font.title.weight(.medium))
                .foregroundColor(.red)
                .padding()

            Text("Search Query Missing!\nPlease enter a search query to be able to search the database!")
                .fixedSize(horizontal: false, vertical: true)   // Allow lines to wrap around
                .multilineTextAlignment(.center)
                .padding(.horizontal)
        }
        }

        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)

        //.background(Color(red: 1.0, green: 1.0, blue: 240/255))     // Ivory color
    }
    
}

struct SearchContacts_Previews: PreviewProvider {
    static var previews: some View {
        SearchContacts()
    }
}
