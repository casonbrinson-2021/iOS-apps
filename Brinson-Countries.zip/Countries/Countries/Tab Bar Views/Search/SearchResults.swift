
//

//  SearchResults.swift

//  Countries

//

//  Created by Cason Brinson on 9/17/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.

//

 

import SwiftUI

import MapKit

 

struct SearchResults: View {

   

    // Subscribe to changes in UserData

    @EnvironmentObject var userData: UserData

   

    @State private var showCountryAddedAlert = false

   

    var body: some View {

        // A Form cannot have more than 10 Sections.

        // Group the Sections if more than 10.

        Form {

            Group {

                Section(header: Text("Country Name")) {

                    // Global variable countryFound is given in CountryApiData.swift

                    Text(countryFound.name)

                }

                Section(header: Text("Country Flag Image")) {

                    // Public function getImageFromUrl is given in UtilityFunctions.swift

                    getImageFromUrl(url: countryFound.flagImageUrl, defaultFilename: "ImageUnavailable")

                        .resizable()

                        .aspectRatio(contentMode: .fit)

                        .frame(minWidth: 300, maxWidth: 500, alignment: .center)

                }

                Section(header: Text("Country alpha2code")) {

                    Text(countryFound.alpha2code)

                }

                Section(header: Text("Country Map")) {

                    NavigationLink(destination: countryMap) {

                        HStack {

                            Image(systemName: "map.fill")

                                .imageScale(.medium)

                                .font(Font.title.weight(.regular))

                                .foregroundColor(.blue)

                            Text("Show Country Map")

                                .font(.system(size: 16))

                        }

                        .frame(minWidth: 300, maxWidth: 500, alignment: .leading)

                    }

                }

                Section(header: Text("Add this country to my favorites list")) {

                    Button(action: {

                        // Append the country found to userData.countriesList

                        self.userData.countriesList.append(countryFound)

 

                        // Set the global variable point to the changed list

                        countryStructList = self.userData.countriesList

                       

                        let selectedCountryAttributesForSearch = "\(countryFound.id)|\(countryFound.name)|\(countryFound.alpha2code)|\(countryFound.capital)|\(countryFound.languages)|\(countryFound.currency)"

                       

                        self.userData.searchableOrderedCountriesList.append(selectedCountryAttributesForSearch)

                       

                        // Set the global variable point to the changed list

                        orderedSearchableCountriesList = self.userData.searchableOrderedCountriesList

                       

                        self.showCountryAddedAlert = true

                    }) {

                        HStack {

                            Image(systemName: "plus")

                                .imageScale(.medium)

                                .font(Font.title.weight(.regular))

                                .foregroundColor(.blue)

                            Text("Add Country to Favorites")

                                .font(.system(size: 16))

                        }

                    }

                }

                Section(header: Text("Capital City")) {

                    Text(countryFound.capital)

                }

            }

            Group {

                Section(header: Text("Population")) {

                    countryPopulation

                }

                Section(header: Text("Total Area in Square Kilometers")) {

                    countryTotalArea

                }

                Section(header: Text("Languages")) {

                    Text(countryFound.languages)

                }

                Section(header: Text("Currency")) {

                    Text(countryFound.currency)

                }

                Section(header: Text("Center Geolocation Latitude")) {

                    Text(String(countryFound.latitude))

                }

                Section(header: Text("Center Geolocation Longitude")) {

                    Text(String(countryFound.longitude))

                }

            }

 

        }   // End of Form

            .navigationBarTitle(Text("Country Details"), displayMode: .inline)

            .alert(isPresented: $showCountryAddedAlert, content: { self.countryAddedAlert })

            .font(.system(size: 14))

    }

   

    var countryMap: some View {

       

        return AnyView(MapView(mapType: MKMapType.standard, latitude: countryFound.latitude, longitude: countryFound.longitude, delta: countryFound.delta, deltaUnit: countryFound.deltaUnit, annotationTitle: countryFound.name, annotationSubtitle: countryFound.capital)

                .navigationBarTitle(Text(countryFound.name), displayMode: .inline)

                .edgesIgnoringSafeArea(.all) )

    }

   

    var countryPopulation: Text {

        let populationInt = countryFound.population

       

        // Add thousand separators to populationInt

        let numberFormatter = NumberFormatter()

        numberFormatter.usesGroupingSeparator = true

        numberFormatter.groupingSize = 3

       

        let populationString = numberFormatter.string(from: populationInt as NSNumber)

        return Text(populationString!)

    }

   

    var countryTotalArea: Text {

        // Total area is in Square Kilometers

        let areaInt = Int(countryFound.area)

       

        // Add thousand separators to areaInt

        let numberFormatter = NumberFormatter()

        numberFormatter.usesGroupingSeparator = true

        numberFormatter.groupingSize = 3

       

        let areaString = numberFormatter.string(from: areaInt as NSNumber)

        return Text(areaString!)

    }

   

    var countryAddedAlert: Alert {

        Alert(title: Text("Country Added!"),

              message: Text("This country is added to your favorites list!"),

              dismissButton: .default(Text("OK")) )

    }

   

}

 

 

struct SearchResults_Previews: PreviewProvider {

    static var previews: some View {

        SearchResults()

    }

}

 
