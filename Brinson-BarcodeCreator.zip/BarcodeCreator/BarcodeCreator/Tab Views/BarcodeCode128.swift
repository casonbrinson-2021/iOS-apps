//
//  BarcodeCode128.swift
//  BarcodeCreator
//
//  Created by Cason Brinson on 9/26/20.
//  Copyright © 2020 Cason Brinson. All rights reserved.
//


import SwiftUI

 

struct BarcodeCode128: View {

   

    @State private var textFieldValue = ""

    @State private var valueEntered = ""

   

    var body: some View {

        NavigationView {

            Form {

                Section {

                    Text("Code 128 barcode is a high-density linear barcode symbology defined in ISO/IEC 15417:2007. It is used for alphanumeric or numeric-only barcodes. It can encode all 128 characters of ASCII and, by use of an extension symbol (FNC4), the Latin-1 characters defined in ISO/IEC 8859-1.")

                        .font(.custom("Helvetica", size: 14))

                }

                Section {

                    HStack {

                        TextField("Enter input to generate barcode", text: $textFieldValue,

                                  onCommit: {

                                    // Record entered value after Return key is pressed

                                    self.valueEntered = self.textFieldValue

                                  })

                            .font(.subheadline)

                            .textFieldStyle(RoundedBorderTextFieldStyle())

                            .keyboardType(.default)

                            .autocapitalization(.none)

                            .disableAutocorrection(true)

                       

                        // Button to clear the text field

                        Button(action: {

                            self.textFieldValue = ""

                            self.valueEntered = ""

                        }) {

                            Image(systemName: "clear")

                                .imageScale(.medium)

                                .font(Font.title.weight(.regular))

                        }

                    }   // End of HStack

                    .padding(.horizontal)

                    .frame(minWidth: 300, maxWidth: 500, alignment: .center)

                   

                }   // End of Section

               

                if !valueEntered.isEmpty {

                    Section {

                        NavigationLink(destination: barcodeGeneration) {

                            HStack {

                                Image(systemName: "gear")

                                    .imageScale(.medium)

                                    .font(Font.title.weight(.regular))

                                    .foregroundColor(.blue)

                                Text("Generate Code 128 Barcode")

                                    .font(.system(size: 16))

                            }

                        }

                        .frame(minWidth: 300, maxWidth: 500, alignment: .center)

                    }

                }

               

            }   // End of Form

            .navigationBarTitle(Text("Generate Code 128 Barcode"), displayMode: .inline)

           

        }   // End of NavigationView

        // Use single column navigation view for iPhone and iPad

        .navigationViewStyle(StackNavigationViewStyle())

       

    }   // End of body

   

    var barcodeGeneration: some View {

        let barcodeImage: UIImage = createBarcode(from: valueEntered, type: "CICode128BarcodeGenerator", scaleFactor: 3)!

        return AnyView(

            BarcodeCreated(input: valueEntered, image: barcodeImage)

                .navigationBarTitle(Text("Generated Code 128 Barcode"), displayMode: .inline)

        )

    }

}

 

struct BarcodeCode128_Previews: PreviewProvider {

    static var previews: some View {

        BarcodeCode128()

    }

}

 
