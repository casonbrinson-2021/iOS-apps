//
//  Contact.swift
//  MyContacts
//
//  Created by Gregory Cason Brinson on 12/7/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//



import Foundation
import CoreData

public class Contact: NSManagedObject, Identifiable {

    @NSManaged public var firstName: String?
    @NSManaged public var lastName: String?
    @NSManaged public var company: String?
    @NSManaged public var phone: String?
    @NSManaged public var email: String?
    @NSManaged public var url: String?
    @NSManaged public var notes: String?
    @NSManaged public var addressLine1: String?
    @NSManaged public var addressLine2: String?
    @NSManaged public var addressCity: String?
    @NSManaged public var addressState: String?
    @NSManaged public var addressZipcode: String?
    @NSManaged public var addressCountry: String?

    @NSManaged public var photo: Photo?

}

extension Contact {

    static func allContactsFetchRequest() -> NSFetchRequest<Contact> {

        let request: NSFetchRequest<Contact> = Contact.fetchRequest() as! NSFetchRequest<Contact>

        request.sortDescriptors = [
            // Primary sort key: lastName
            NSSortDescriptor(key: "lastName", ascending: true),
            NSSortDescriptor(key: "firstName", ascending: true)
        ]

        return request
    }

    static func filteredContactsFetchRequest(searchCategory: String, searchQuery: String) -> NSFetchRequest<Contact> {

        let fetchRequest = NSFetchRequest<Contact>(entityName: "Contact")

        fetchRequest.sortDescriptors = [
            // Primary sort key: artistName
            NSSortDescriptor(key: "lastName", ascending: true),
            NSSortDescriptor(key: "firstName", ascending: true)
        ]

    
        // Case insensitive search [c] for searchQuery under each category
        switch searchCategory {

        case "First Name":
            fetchRequest.predicate = NSPredicate(format: "firstName CONTAINS[c] %@", searchQuery)

        case "Last Name":
            fetchRequest.predicate = NSPredicate(format: "lastName CONTAINS[c] %@", searchQuery)

        case "Company Name":
            fetchRequest.predicate = NSPredicate(format: "company CONTAINS[c] %@", searchQuery)

        case "Notes":
            fetchRequest.predicate = NSPredicate(format: "notes CONTAINS[c] %@", searchQuery)

        case "City Name":
            fetchRequest.predicate = NSPredicate(format: "addressCity CONTAINS[c] %@", searchQuery)
            
        case "State Abbreviation":
            fetchRequest.predicate = NSPredicate(format: "addressState CONTAINS[c] %@", searchQuery)
            
        case "Country Name":
            fetchRequest.predicate = NSPredicate(format: "addressCountry CONTAINS[c] %@", searchQuery)

        case "All":
            fetchRequest.predicate = NSPredicate(format: "firstName CONTAINS[c] %@ OR lastName CONTAINS[c] %@ OR company CONTAINS[c] %@ OR notes CONTAINS[c] %@ OR addressCity CONTAINS[c] %@ OR addressState CONTAINS[c] %@ OR addressCountry CONTAINS[c] %@", searchQuery, searchQuery, searchQuery, searchQuery, searchQuery, searchQuery, searchQuery)

        default:
            print("Search category is out of range")
        }
        return fetchRequest
    }
}

 

